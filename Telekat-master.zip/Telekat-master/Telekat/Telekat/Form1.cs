﻿using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Telekat;

namespace ExternalTool
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void defaultButton_Click(object sender, EventArgs e)
        {
            textBoxKey.Text = "0";
            textBoxTreasure.Text = "0";
            textBoxStatue.Text = "0";
            textBoxLever.Text = "0";
            textBoxButton.Text = "0";
            textBoxCrate.Text = "0";
            MessageBox.Show("Changes have been set to Default");
        }

        private void labelTreasure_Click(object sender, EventArgs e)
        {

        }

        private void labelStatue_Click(object sender, EventArgs e)
        {

        }

        private void labelKey_Click(object sender, EventArgs e)
        {

        }

        private void textBoxKey_TextChanged(object sender, EventArgs e)
        {
            int keyNum = textBoxKey.Text;
        }

        private void textBoxTreasure_TextChanged(object sender, EventArgs e)
        {
            int treasureNum = textBoxTreasure.Text;
        }

        private void textBoxStatue_TextChanged(object sender, EventArgs e)
        {
            int statueNum = textBoxStatue.Text;
        }

        private void applyButton_Click(object sender, EventArgs e, int keyNum, int treasureNum, int statueNum, int leverNum, int buttonNum, int crateNum)
        {
            for (int i = 0; i < keyNum; i++)
            {
                Key myKey = new Key(1, 1, 1, 1, , "");
            }

            for (int i = 0; i < treasureNum; i++)
            {
                Platform myPlatform = new Platform(1, 1, 1, 1, , "");
            }

            for (int i = 0; i < statueNum; i++)
            {
                Ladder myLadder = new Ladder(1, 1, 1, 1, , "");
            }

            for (int i = 0; i < leverNum; i++)
            {
                Lever myLever = new Lever(1, 1, 1, 1, , "");
            }

            for (int i = 0; i < buttonNum; i++)
            {
                Rock myRock = new Rock(1, 1, 1, 1, , "");
            }

            for (int i = 0; i < crateNum; i++)
            {
                Rope myRope = new Rope(1, 1, 1, 1, , "");
            }
        }

        private void textBoxLever_TextChanged(object sender, EventArgs e)
        {
            int leverNum = textBoxLever.Text;
        }

        private void labelLever_Click(object sender, EventArgs e)
        {

        }

        private void textBoxButton_TextChanged(object sender, EventArgs e)
        {
            int buttonNum = textBoxButton.Text;
        }

        private void labelButton_Click(object sender, EventArgs e)
        {

        }

        private void labelCrate_Click(object sender, EventArgs e)
        {
            
        }

        private void textBoxCrate_TextChanged(object sender, EventArgs e)
        {
            int crateNum = textBoxCrate.Text;
        }
    }
}
