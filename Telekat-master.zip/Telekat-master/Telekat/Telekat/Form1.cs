﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExternalTool
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void defaultButton_Click(object sender, EventArgs e)
        {
            textBoxKey.Text = "0";
            textBoxTreasure.Text = "0";
            textBoxStatue.Text = "0";
            textBoxLever.Text = "0";
            textBoxButton.Text = "0";
            textBoxCrate.Text = "0";
            MessageBox.Show("Changes have been set to Default");
        }

        private void labelTreasure_Click(object sender, EventArgs e)
        {

        }

        private void labelStatue_Click(object sender, EventArgs e)
        {

        }

        private void labelKey_Click(object sender, EventArgs e)
        {

        }

        private void textBoxKey_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxTreasure_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxStatue_TextChanged(object sender, EventArgs e)
        {

        }

        private void applyButton_Click(object sender, EventArgs e)
        {
            
        }

        private void textBoxLever_TextChanged(object sender, EventArgs e)
        {

        }

        private void labelLever_Click(object sender, EventArgs e)
        {

        }

        private void textBoxButton_TextChanged(object sender, EventArgs e)
        {

        }

        private void labelButton_Click(object sender, EventArgs e)
        {

        }

        private void labelCrate_Click(object sender, EventArgs e)
        {

        }

        private void textBoxCrate_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
