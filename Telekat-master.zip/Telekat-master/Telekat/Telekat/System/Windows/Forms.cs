﻿namespace System.Windows
{
    internal class Forms
    {
    }
}