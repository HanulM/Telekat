﻿using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Telekat
{
    internal class Rock : Items
    {

        //Constructor 
        public Rock(int x, int y, int width, int height, Texture2D texture):base(x, y, width, height, texture)
        {

        }

    }
}
