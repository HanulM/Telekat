﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Telekat
{
    class Physics
    {
        // Attributes
        //Klaus klaus = new Klaus();
        //Items myItems = new Items();

        // Properties


        // Methods
        // Collision Detection
        public bool Collided()
        {
            /*
             * if(klaus.characterBox.Contains(myItems.itemBox)
             * {
             *      return true;
             * }
             */

            return false; //else
        }

        // Gravity
        public void Gravity(Klaus player)
        {

        }
    }
}
