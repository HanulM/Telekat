﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Telekat
{
    class Lever : Items
    {

        //Constructor 
        public Lever(int x, int y, int width, int height, Texture2D texture) : base(x, y, width, height, texture)
        {
            
        }

        //State Machine
        var leverState = new stateMachine<State, Input>(State.UnChecked);

        stateMachine.Configure(stateMachine.Checked)
            .Permit(Input.Flip, stateMachine.UnChecked)
            .PermitReentry(Input.Push);

        stateMachine.Configure(stateMachine.UnChecked);
            .Permit(Input.Push, State.Checked)
            .PermitReentry(Input.Flip);
        
    }
}
